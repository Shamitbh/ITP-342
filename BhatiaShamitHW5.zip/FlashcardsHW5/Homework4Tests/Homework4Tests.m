//
//  Homework4Tests.m
//  Homework4Tests
//
//  Created by Shamit Bhatia on 03/28/18.
//  Copyright © 2017 Shamit Bhatia. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "FlashcardsModel.h"
@interface Homework4Tests : XCTestCase

@property (strong, nonatomic) FlashcardsModel *flashcardModel;

@end

@implementation Homework4Tests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
    self.flashcardModel = [[FlashcardsModel alloc] init];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}


- (void) testSharedModel{
    FlashcardsModel *f1 = [FlashcardsModel sharedModel];
    [f1 insertWithQuestion: @"New question" answer: @"New Answer" favorite:YES];
    
     FlashcardsModel *f2 = [FlashcardsModel sharedModel];

    
    XCTAssertEqual([f1 numberOfFlashcards], [f2 numberOfFlashcards]);
    
}


- (void) testRandomFlashcard{
    XCTAssertNotNil([self.flashcardModel randomFlashcard]);
}

- (void) testFlashcardAtIndex {

    XCTAssertNotEqual ([self.flashcardModel flashcardAtIndex:0 ], [self.flashcardModel flashcardAtIndex:1]);
}


- (void) testNextFlashcard {
    
    NSUInteger currentIndex = [self.flashcardModel currentIndex];
    XCTAssertEqual([self.flashcardModel nextFlashcard], [self.flashcardModel flashcardAtIndex:currentIndex + 1]);
    
}

- (void) testPrevFlashcard {
    
    [self.flashcardModel nextFlashcard];
    NSUInteger currentIndex = [self.flashcardModel currentIndex];
    XCTAssertEqual([self.flashcardModel prevFlashcard], [self.flashcardModel flashcardAtIndex:currentIndex -1]);
}



- (void)testAddFlashcard {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
    NSUInteger numberOfFlashcardsBefore = [self.flashcardModel numberOfFlashcards];
    
    [self.flashcardModel insertWithQuestion:@"New question" answer: @"New answer"favorite: YES] ;
    

    NSUInteger numberOfFlashcardsAfter = [self.flashcardModel numberOfFlashcards];
    
    XCTAssertEqual(numberOfFlashcardsBefore + 1, numberOfFlashcardsAfter);
    
                                
}


- (void)testAddFlashcardAtIndex {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
    NSUInteger numberOfFlashcardsBefore = [self.flashcardModel numberOfFlashcards];
    
    [self.flashcardModel insertWithQuestion:@"New question"answer:@"New answer" favorite:YES atIndex:4];
    
    
    NSUInteger numberOfFlashcardsAfter = [self.flashcardModel numberOfFlashcards];
    
    XCTAssertEqual(numberOfFlashcardsBefore + 1, numberOfFlashcardsAfter);
}

- (void)testRemoveFlashcard {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
    NSUInteger numberOfFlashcardsBefore = [self.flashcardModel numberOfFlashcards];
    
    [self.flashcardModel removeFlashcard];
    
    
    NSUInteger numberOfFlashcardsAfter = [self.flashcardModel numberOfFlashcards];
    
    XCTAssertEqual(numberOfFlashcardsBefore-1, numberOfFlashcardsAfter);
}

- (void)testRemoveFlashcardAtIndex {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
    NSUInteger numberOfFlashcardsBefore = [self.flashcardModel numberOfFlashcards];
    
    [self.flashcardModel removeFlashcardAtIndex: 3];
    
    
    NSUInteger numberOfFlashcardsAfter = [self.flashcardModel numberOfFlashcards];
    
    XCTAssertEqual(numberOfFlashcardsBefore-1, numberOfFlashcardsAfter);
}

- (void) testToggleFlashcard {
    
    BOOL prevFavState = [[self.flashcardModel flashcardAtIndex:[self.flashcardModel currentIndex]] isFavorite];
    [self.flashcardModel toggleFavorite];
    BOOL newFavState = [[self.flashcardModel flashcardAtIndex:[self.flashcardModel currentIndex]] isFavorite];
    XCTAssertNotEqual(prevFavState, newFavState);
}


-(void) testFavoriteFlashcard {
    // how many flashcards are favorite
    
    NSUInteger numOfFavs = 0;
    
    for (int i = 0; i < [self.flashcardModel numberOfFlashcards]; i ++ ) {
        if ( [[self.flashcardModel flashcardAtIndex:[self.flashcardModel currentIndex]] isFavorite] ) {
            numOfFavs ++;
        }
    }
    
    
    NSArray *flashArray =  [self.flashcardModel favoriteFlashcards];
    NSUInteger numFavWithArray = flashArray.count;
    
    XCTAssertEqual(numOfFavs,numFavWithArray);
   
    
}



- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
