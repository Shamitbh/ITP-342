//
//  FlashcardsModel.m
//  Homework4
//
//  Created by Shamit Bhatia on 03/29/18.
//  Copyright © 2017 Shamit Bhatia. All rights reserved.
//


#import "FlashcardsModel.h"


@interface FlashcardsModel ()

@property (nonatomic, strong) NSMutableArray* flashcards;
@property (strong, nonatomic) NSString* filePath;

@end

@implementation FlashcardsModel

- (instancetype) init {
    self = [super init];
    
    if (self) {
        
        _currentIndex = 0;
        
        // get documents directory path
        NSString *documentsDirectoryPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
        
        // // Create a file name for your file
        NSString *filename = @"flashcards.plist";
        
        // Generate the full file path
        
        _filePath = [NSString stringWithFormat:@"%@/%@", documentsDirectoryPath, filename];
        
        NSLog(@"file path %@", _filePath);
        
        NSArray *flashcardsFromDocumentsDir = [[NSArray alloc] initWithContentsOfFile:_filePath];
		
        if (flashcardsFromDocumentsDir != nil){
            _flashcards = [[NSMutableArray alloc] init];
            NSDictionary* newcards;
            Flashcard* flashcard;
            for (newcards in flashcardsFromDocumentsDir) {
                flashcard = [[Flashcard alloc] initWithDictionary:newcards];
                [_flashcards addObject: flashcard];
            }


        }
		
        else if(!_flashcards) {
            // create a default list of flashcards
            
            //_currentIndex = 0; *******
            
            Flashcard *f1;
            Flashcard *f2;
            Flashcard *f3;
            Flashcard *f4;
            Flashcard *f5;
            
            
            
            f1 = [[Flashcard alloc] initWithQuestion: @"Which U.S. state has the longest coastline?" answer: @"Alaska (6,640 miles)"];
            
            f2 = [[Flashcard alloc] initWithQuestion: @"Which U.S. president appears on the front of the $2 bill?" answer: @"Thomas Jefferson"];
            
            f3 = [[Flashcard alloc] initWithQuestion: @"What is the capital city of the U.S. state of Hawaii?" answer: @"Honolulu"];
            
            f4 = [[Flashcard alloc] initWithQuestion: @"What US state is famous for its juicy peaches?" answer: @"Georgia"];
            
            f5 = [[Flashcard alloc] initWithQuestion: @"In which U.S. state would you find Mount Rushmore?" answer: @"South Dakota"];
            
            _flashcards = [[NSMutableArray alloc] initWithObjects: f1, f2, f3, f4, f5, nil];
            
        }

        
//        else {
//            NSDictionary* newcards;
//            Flashcard* flashcard;
//            for (_flashcards in newcards) {
//                flashcard = [[Flashcard alloc] initWithDictionary:newcards];
//                [_flashcards addObject: flashcard];
//            }
//        }
    }
return self;
    
}


// Creating the model
+ (instancetype) sharedModel{
    static FlashcardsModel *flashcardsModel = nil;
    
    // Grand Central Dispatch
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        flashcardsModel = [[FlashcardsModel alloc] init];
    });
    
    return flashcardsModel;
}

//// Accessing a flashcard – sets currentIndex appropriately
- (NSUInteger) numberOfFlashcards {
    return (NSUInteger)self.flashcards.count;
    //defining function use udnerscore
    
}
//// Accessing a flashcard – sets currentIndex appropriately
- (Flashcard *) randomFlashcard{
    int currIndex = (int)arc4random_uniform((uint32_t)self.flashcards.count);
    _currentIndex = currIndex;
    if (_flashcards.count == 0 ){
        return nil;
    }

    return self.flashcards[currIndex];
}

- (Flashcard *) flashcardAtIndex: (NSUInteger) index{
    return self.flashcards[index];
}

- (Flashcard *) nextFlashcard {
    
    if ((self.currentIndex) < self.flashcards.count - 1 ){
        _currentIndex = _currentIndex +1;
        return self.flashcards[self.currentIndex];
        
    }
    _currentIndex = 0;
    
    return self.flashcards[self.currentIndex];
    
    
    
    
}
- (Flashcard *) prevFlashcard
{
    if ((self.currentIndex) != 0) {
        {
            _currentIndex = _currentIndex - 1;
            return self.flashcards[self.currentIndex];
            
        }
    }
    _currentIndex = (int) self.flashcards.count - 1;
    return self.flashcards[self.currentIndex];
}

// Inserting a flashcard
- (void) insertWithQuestion: (NSString *) question
                     answer: (NSString *) ans
                   favorite: (BOOL) fav{
    
    Flashcard *flashcardToInsert;
    flashcardToInsert = [[Flashcard alloc] initWithQuestion:question answer: ans isFavorite: fav];
    
    [self.flashcards addObject:flashcardToInsert];
    [self save];
    
    
}
- (void) insertWithQuestion: (NSString *) question
                     answer: (NSString *) ans
                   favorite: (BOOL) fav
                    atIndex: (NSUInteger) index{
    
    Flashcard *flashcardToInsert;
    flashcardToInsert = [[Flashcard alloc] initWithQuestion:question answer:ans isFavorite: fav];
    
    if(index <=self.flashcards.count) {
        
        [self.flashcards insertObject: flashcardToInsert atIndex:index];
        [self save];
        
    }
    
    
}

// Removing a flashcard
- (void) removeFlashcard{
    
    [self.flashcards removeLastObject];
    [self save];
    
}


- (void) removeFlashcardAtIndex: (NSUInteger) index{
    if (_currentIndex < self.flashcards.count) {
        [self.flashcards removeObjectAtIndex: index];
        [self save];
        
    }
    
}

//makes it so that we don't have to remidn the user to save
- (void) save {
    // show user defaults?
    
    NSMutableArray *fcs = [[NSMutableArray alloc] init];
    
    for (Flashcard* fc in self.flashcards) {
        NSDictionary *flashcardDict = [fc convertForPList];
        [fcs addObject: flashcardDict];
    }
    [fcs writeToFile:self.filePath atomically:YES];
}


// Favorite/unfavorite the current flashcard
- (void) toggleFavorite {
    Flashcard *currFlashCard = self.flashcards[self.currentIndex];
    if ((![currFlashCard isFavorite])) {
        [currFlashCard setIsFavorite:true];
    }
    
    else {
        [currFlashCard setIsFavorite:false];
    }
    
}
// Getting the favorite flashcards !!!
- (NSArray *) favoriteFlashcards{
    NSMutableArray *favoriteFlashcardsMute;
    
    for(int i = 0; i <self.flashcards.count; i++){
        if([self.flashcards[i] isFavorite])
            [favoriteFlashcardsMute addObject:self.flashcards[i]];
    }
    
    
    NSArray *favoriteFlashCards;
    favoriteFlashCards = [[NSArray alloc] initWithArray:favoriteFlashCards];
    return favoriteFlashCards;
}

@end
