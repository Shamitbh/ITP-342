//
//  TableViewController.m
//  Homework4
//
//  Created by Shamit Bhatia on 04/06/18.
//  Copyright © 2017 Shamit Bhatia. All rights reserved.
//

#import "FlashcardsTableViewController.h"
#import "FlashcardsModel.h"
#import "AddViewController.h"

@interface FlashcardsTableViewController ()

@property (nonatomic, strong) FlashcardsModel *fcModel; // what is the supposed to be

@end

@implementation FlashcardsTableViewController


#pragma mark

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    //have navigation bar display on the left
    self.navigationItem.leftBarButtonItem = self.editButtonItem;
    
    // call singleton
    self.fcModel = [FlashcardsModel sharedModel];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Table view data source

// data source methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.fcModel numberOfFlashcards];
}

- (UITableViewCell *) tableView: (UITableView *) tableView cellForRowAtIndexPath:(NSIndexPath *) indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"FlashcardCell" forIndexPath:indexPath];
    
    // Configure the cell...
    
 
    NSString *tableCellText;
    
    Flashcard *fc = [self.fcModel flashcardAtIndex: indexPath.row];
   
    tableCellText = [NSString stringWithFormat:
                     @"%@", [fc question]];
    
    cell.textLabel.text = tableCellText;
    
    return cell;
    
}






 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 

// to delete cells ????

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        
        // Delete the row from the data source
        [self.fcModel removeFlashcardAtIndex:indexPath.row];
        
        
        // animation that deletes the cell
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }

 
}

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    // NSLog(@"%s %@ %@", __FUNCTION__, segue.sourceViewController, segue.destinationViewController);
    
    
    // Get the new view controller using [segue destinationViewController].
    AddViewController *addVC = segue.destinationViewController;
    
    // set public property placeholderInput1
    addVC.placeHolderForAnswer = @"Answer";
    
    //set completion block
    addVC.completionHandler = ^(NSString *q, NSString *ans) {
        
    
        if (q.length > 0 && ans.length > 0) {
            
            
            // add flashcard to model
            [self.fcModel insertWithQuestion: q answer: ans favorite: FALSE];
            
            // update table view
            [self.tableView reloadData];
        }
        
            // Make the view controller go away
            [self dismissViewControllerAnimated:YES completion:nil];
    
            
        
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    };
    
}
    @end
    
    
