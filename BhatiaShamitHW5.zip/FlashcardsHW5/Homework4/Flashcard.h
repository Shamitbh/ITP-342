//
//  Flashcard.h
//  Homework4
//
//  Created by Shamit Bhatia on 03/29/18.
//  Copyright © 2017 Shamit Bhatia. All rights reserved.
//

#import <Foundation/Foundation.h>

// constants
static NSString * const kQuestionKey = @"question";
static NSString * const kAnswerKey = @"answer";
static NSString * const kFavoriteKey = @"favorite";
static NSString * const kIsFavoriteKey = @"yes";
static NSString * const kNotFavoriteKey = @"no";

@interface Flashcard : NSObject


@property (readonly, strong, nonatomic) NSString * question;
@property (readonly, strong, nonatomic) NSString * answer;

@property BOOL isFavorite;

// Initializing the flashcard
- (instancetype) initWithQuestion: (NSString *) question
                           answer: (NSString *) ans;
- (instancetype) initWithQuestion: (NSString *) question
                           answer: (NSString *) ans
                       isFavorite: (BOOL) isFav;


- (instancetype) initWithDictionary: (NSDictionary *) cards;
- (NSDictionary *) convertForPList;


@end
