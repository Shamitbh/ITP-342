//
//  FlashcardModel.h
//  Homework4
//
//  Created by langa tran on 10/22/17.
//  Copyright © 2017 Langa Tran. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FlashcardModel : NSObject

@end
