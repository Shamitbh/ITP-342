//
//  Flashcard.m
//  Homework4
//
//  Created by Shamit Bhatia on 03/29/18.
//  Copyright © 2017 Shamit Bhatia. All rights reserved.
//

#import "Flashcard.h"

@implementation Flashcard

- (instancetype) initWithQuestion: (NSString *) question
                           answer: (NSString *) ans {
    self = [super init];
     
    if (self){
        _question = question;
        _answer = ans;
    }
    
    return self;
    
}

- (instancetype) initWithQuestion: (NSString *) question
                           answer: (NSString *) ans
                       isFavorite: (BOOL) isFav {
    self = [super init];
    
    if (self){
        _question = question;
        _answer = ans;
        _isFavorite = isFav;
    }
    
    return self;
    
    
}

- (instancetype) initWithDictionary: (NSDictionary *) cards {
    self = [super init];
    if (self) {
        BOOL fav = NO;
        NSString* favString = [cards valueForKey: kFavoriteKey];
        if ([favString isEqualToString:kIsFavoriteKey]) {
            fav = YES;
        }
        
        _question = [cards valueForKey: kQuestionKey];
        _answer = [cards valueForKey: kAnswerKey];
        _isFavorite= fav;
    }
    return self;
}

- (NSDictionary *) convertForPList {
    
    NSString* favorite = kNotFavoriteKey;
    if (self.isFavorite) {
        favorite = kIsFavoriteKey;
    }
    NSDictionary *flashcard = [NSDictionary dictionaryWithObjectsAndKeys:
                            self.question, kQuestionKey,
                            self.answer, kAnswerKey,
                            favorite, kFavoriteKey,
                            nil];
    
    return flashcard;
}





@end
