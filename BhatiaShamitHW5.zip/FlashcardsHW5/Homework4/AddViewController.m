//
//  AddViewController.m
//  Homework4
//
//  Created by Shamit Bhatia on 04/06/18.
//  Copyright © 2017 Shamit Bhatia. All rights reserved.
//

#import "AddViewController.h"

@interface AddViewController () <UITextFieldDelegate, UITextViewDelegate>

@property (weak, nonatomic) IBOutlet UITextView *questionTextView;
@property (weak, nonatomic) IBOutlet UITextField *answerTextField;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *saveButton;
@property (weak, nonatomic) IBOutlet UILabel *enterInstructionsLabel;

@end

@implementation AddViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    [self.questionTextView becomeFirstResponder];
    
    self.answerTextField.delegate = self; // allows you to use delegate functions instead of predefined functions
    
    self.answerTextField.placeholder = self.placeHolderForAnswer; // call function on place holder
    
    self.enterLabel = @"Please enter question and answer for new flashcard.";
    self.enterInstructionsLabel.text = self.enterLabel;
    
    
    

}

// UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self.answerTextField becomeFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    [self enableOrDisableSaveButton];
    
    return YES;
}

// UITextViewDelegate

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    
    [self enableOrDisableSaveButton];
    
    return YES;
}

// Helper method
- (void)enableOrDisableSaveButton{
    // Validate the input and enable or disable save button accordingly
    if (self.answerTextField.text.length > 0 && self.questionTextView.text.length > 0){
        self.saveButton.enabled = YES;
    } else{
        self.saveButton.enabled = NO;
    }
    
}

- (IBAction)saveButtonDidPressed:(UIBarButtonItem *)sender {
    self.completionHandler(self.questionTextView.text, self.answerTextField.text);
    //NSLog(@"%s", __FUNCTION__);
    
}

- (IBAction)cancelButtonDidPressed:(UIBarButtonItem *)sender {
    
    //NSLog(@"%s", __FUNCTION__);
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}


- (IBAction)dismissKeyboard:(id)sender {
    [sender resignFirstResponder];
}



- (void)touchesBegan:(NSSet<UITouch *> *)touches
           withEvent:(UIEvent *)event{
   
    
    UITouch *touch = [[event allTouches] anyObject];
    
    // click on text view
    if([self.questionTextView isFirstResponder] &&
       [touch view] != self.questionTextView) {
        
        [self.questionTextView resignFirstResponder];
    }
    
    
    // click on answer textfield
    
    if([self.answerTextField isFirstResponder] &&
       [touch view] != self.answerTextField) {
        
        [self.answerTextField resignFirstResponder];
    }
    
    
    
    [super touchesBegan:touches withEvent:event];
    
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
