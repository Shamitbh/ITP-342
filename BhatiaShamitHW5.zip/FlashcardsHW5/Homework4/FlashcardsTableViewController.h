//
//  TableViewController.h
//  Homework4
//
//  Created by Shamit Bhatia on 04/06/18.
//  Copyright © 2017 Shamit Bhatia. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlashcardsTableViewController : UITableViewController

@end
