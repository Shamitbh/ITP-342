//
//  AppDelegate.h
//  Homework4
//
//  Created by Shamit Bhatia on 03/28/18.
//  Copyright © 2017 Shamit Bhatia. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

