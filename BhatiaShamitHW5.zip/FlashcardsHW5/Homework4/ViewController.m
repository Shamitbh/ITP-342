//
//  ViewController.m
//  Homework4
//
//  Created by Shamit Bhatia on 03/28/18.
//  Copyright © 2017 Shamit Bhatia. All rights reserved.
//

#import "ViewController.h"
#import "FlashcardsModel.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UILabel *flashcardLabel;

@property(strong, nonatomic) FlashcardsModel *flashcardsModel;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.flashcardsModel = [FlashcardsModel sharedModel];
    Flashcard *randomFlashcard = [self.flashcardsModel randomFlashcard];
    
    if (randomFlashcard == nil) {
        self.flashcardLabel.text = @"There are no more flashcards";
    }
    
    else {
        self.flashcardLabel.text = randomFlashcard.question;
    }
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapDidRecognized:)];
    [singleTap setNumberOfTouchesRequired:1];
    [singleTap setNumberOfTapsRequired:1];
    
    UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doubleTapDidRecognized:)];
    [doubleTap setNumberOfTouchesRequired:1];
    [doubleTap setNumberOfTapsRequired:2];
    [singleTap requireGestureRecognizerToFail: doubleTap]; // NEED THIS?
    
    UISwipeGestureRecognizer *leftSwipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(leftSwipeDidRecognized:)];
    leftSwipe.direction = UISwipeGestureRecognizerDirectionLeft;
    
    UISwipeGestureRecognizer *rightSwipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(rightSwipeDidRecognized:)];
    rightSwipe.direction = UISwipeGestureRecognizerDirectionRight;
    
    
    // Attach it to my main view
    [self.view addGestureRecognizer:singleTap];
    [self.view addGestureRecognizer:doubleTap];
    [self.view addGestureRecognizer:leftSwipe];
    [self.view addGestureRecognizer:rightSwipe];
    
    [singleTap requireGestureRecognizerToFail:doubleTap];


}
- (void)leftSwipeDidRecognized:(UISwipeGestureRecognizer *)swipe{
    Flashcard *prevFlashcard = [self.flashcardsModel prevFlashcard];
    self.flashcardLabel.text = [prevFlashcard question];
    self.flashcardLabel.textColor = [UIColor colorWithRed:255.0f/255.0f green:0.0 blue:0.0
                                                    alpha:1.0];
    
}

- (void)rightSwipeDidRecognized:(UISwipeGestureRecognizer *)swipe{
    Flashcard *nextFlashcard = [self.flashcardsModel nextFlashcard];
    self.flashcardLabel.text = [nextFlashcard question];
    self.flashcardLabel.textColor = [UIColor colorWithRed:255.0f/255.0f green:0.0 blue:0.0
                                                    alpha:1.0];
    
}


- (void)singleTapDidRecognized:(UITapGestureRecognizer *)tap{
    Flashcard *randomFlashcard = [self.flashcardsModel randomFlashcard];
    
    if (self.flashcardsModel.numberOfFlashcards > 0 ) {
    self.flashcardLabel.text = [randomFlashcard question];
    self.flashcardLabel.textColor =[UIColor colorWithRed:255.0f/255.0f green:0.0 blue:0.0
                                                   alpha:1.0];
    }
    
    else {
        self.flashcardLabel.text = @"There are no more flashcards";
    }
}

- (void)doubleTapDidRecognized:(UITapGestureRecognizer *)tap{
    int index = self.flashcardsModel.currentIndex;
   
    [UIView animateWithDuration:1.0 animations:^{
        // Fade out old text of label
        self.flashcardLabel.alpha = 0;
    } completion:^(BOOL finished) {
        // Upon completion, call
        
        if (self.flashcardsModel.numberOfFlashcards > 0 ) {
            self.flashcardLabel.text = [[self.flashcardsModel flashcardAtIndex:index] answer] ;
        } else {
            self.flashcardLabel.text = @"Please add flashcards.";
        }
        
        self.flashcardLabel.textColor = [UIColor whiteColor];

        
        [UIView animateWithDuration:1.0 animations:^{
            self.flashcardLabel.alpha = 1;
        }];
        
    }];
    
    
}

 - (void) viewWillAppear:(BOOL)animated {
     if (_flashcardsModel.numberOfFlashcards == 0 ){
         self.flashcardLabel.textColor =[UIColor colorWithRed:255.0f/255.0f green:0.0 blue:0.0
                                                       alpha:1.0];
         _flashcardLabel.text = @"There are no more flashcards";
         
         
         
     }
 }



@end
