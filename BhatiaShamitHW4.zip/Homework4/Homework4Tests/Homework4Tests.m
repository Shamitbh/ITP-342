//
//  Homework4Tests.m
//  Homework4Tests
//
//  Created by Shamit Bhatia on 2/28/18.
//  Copyright © 2018 Shamit Bhatia. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "FlashcardsModel.h"

@interface Homework4Tests : XCTestCase
// private properties
@property (strong, nonatomic) FlashcardsModel* model;

@end

@implementation Homework4Tests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
	
	self.model = [[FlashcardsModel alloc] init];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testSharedModel {
	FlashcardsModel *f1 = [FlashcardsModel sharedModel];
	FlashcardsModel *f2 = [FlashcardsModel sharedModel];
	// add a flashcard to model1
	[f1 insertWithQuestion: @"New question" answer: @"New Answer" favorite:YES];
	
	// check model2 for increase in number of flashcards
	XCTAssertEqual([f1 numberOfFlashcards], [f2 numberOfFlashcards]);
}

- (void)testNumberOfFlashcards {
	XCTAssertEqual(5, self.model.numberOfFlashcards);
}

- (void)testRandomFlashcard {
	// Create two flashcards and make sure they are not equal (b/c of the way I implemented my randomFlashcard method
	Flashcard *f1 = [self.model randomFlashcard];
	Flashcard *f2 = [self.model randomFlashcard];
	XCTAssertNotEqual(f1, f2);
}

- (void)testFlashcardAtIndex {
	// Check that the indices are different and the flashcards are in turn different
	XCTAssertNotEqual([self.model flashcardAtIndex:0 ], [self.model flashcardAtIndex:1]);
}

- (void)testNextFlashcard {

	NSUInteger currentIndex = [self.model currentIndex];
	// test the two flashcards - the next flashcard and the flashcard with currentIndex + 1
	XCTAssertEqual([self.model nextFlashcard], [self.model flashcardAtIndex:currentIndex + 1]);
}

- (void)testPrevFlashcard {
	// Go to next flash card, which increases currentIndex
	[self.model nextFlashcard];
	NSUInteger currentIndex = [self.model currentIndex];
	// Check the previous flashcard with a flashcard at currentIndex - 1, they shold be equal
	XCTAssertEqual([self.model prevFlashcard], [self.model flashcardAtIndex:currentIndex -1]);
}

- (void)testInsertFlashcard {
	NSUInteger numFlashcardsInitial = [self.model numberOfFlashcards];
	// insert a flashcard without index (should add to the end and increase numFlashcards)
	[self.model insertWithQuestion:@"New question" answer: @"New answer"favorite: YES];
	
	
	XCTAssertNotEqual(numFlashcardsInitial, [self.model numberOfFlashcards]);
}

- (void)testInsertFlashcardAtIndex {
	// Get a flashcard at some index (2). Then insert a flashcard at index 2. They should NOT be the same
	Flashcard *f1 = [self.model flashcardAtIndex:2];
	// Insertion at 2
	[self.model insertWithQuestion:@"New question" answer:@"New answer" favorite:YES atIndex:2];
	Flashcard *f2 = [self.model flashcardAtIndex:2];
	
	XCTAssertNotEqual(f1, f2);
}

- (void)testRemoveFlashcard {
	NSUInteger numFlashcardsInitial = [self.model numberOfFlashcards];
	// Remove flashcard
	[self.model removeFlashcard];
	// Now the num flashcards should not be the same.
	XCTAssertNotEqual(numFlashcardsInitial, [self.model numberOfFlashcards]);
}

- (void)testRemoveFlashcardAtIndex {
	// Get flashcard at index 2
	Flashcard *f1 = [self.model flashcardAtIndex:2];
	
	// Now emove a flashcard at index 2
	[self.model removeFlashcardAtIndex: 2];

	// Now the flashcard at index 2 and the initial flashcard should not be the same.
	XCTAssertNotEqual(f1, [self.model flashcardAtIndex:2]);
}

- (void)testToggleFavorite {
	// Get the current index flashcard. Then see it's BOOL favorite state. Then toggle the state. It should be different then.
	BOOL prevState = [[self.model flashcardAtIndex:[self.model currentIndex]] isFavorite];
	// Toggle the state
	[self.model toggleFavorite];
	// New state
	BOOL newState = [[self.model flashcardAtIndex:[self.model currentIndex]] isFavorite];
	XCTAssertNotEqual(prevState, newState);
}

- (void)testFavoriteFlashcards {
	// Go through each cards manually and see if favorite - then keep a count for it
	NSUInteger numFavorites = 0;
	for (int i = 0; i < [self.model numberOfFlashcards]; i++) {
		if ([[self.model flashcardAtIndex:[self.model currentIndex]] isFavorite] ) {
			numFavorites++;
		}
	}
	
	// Test this against the favoriteFlashcards method to see how many count is in that NSArray
	NSArray *flashArray =  [self.model favoriteFlashcards];
	NSUInteger numFavWithArray = flashArray.count;
	
	XCTAssertEqual(numFavorites,numFavWithArray);
}


- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
