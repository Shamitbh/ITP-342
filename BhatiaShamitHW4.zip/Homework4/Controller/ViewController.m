//
//  ViewController.m
//  Homework4
//
//  Created by Shamit Bhatia on 2/28/18.
//  Copyright © 2018 Shamit Bhatia. All rights reserved.
//

#import "ViewController.h"
#import "FlashcardsModel.h"

@interface ViewController ()

// private properties


@property (weak, nonatomic) IBOutlet UILabel *flashcardLabel;

@property (strong, nonatomic) FlashcardsModel* model;

@end

@implementation ViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
	self.model = [FlashcardsModel sharedModel];
	
	// Get random flashcard and display question
	Flashcard *randomFlashcard = [self.model randomFlashcard];
	self.flashcardLabel.text = [randomFlashcard question];
	
	// Gestures - single/double tap
	UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapRecognized:)];
	
	[self.view addGestureRecognizer: singleTap];
	UITapGestureRecognizer *doubleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doubleTapRecognized:)];
	doubleTap.numberOfTapsRequired = 2;
	[self.view addGestureRecognizer: doubleTap];
	// Only recognize single taps if they're not the first of two
	[singleTap requireGestureRecognizerToFail: doubleTap];
	
	// Gestures - left/right swipe
	
	UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(leftSwipeRecognized:)];
	swipeLeft.direction = UISwipeGestureRecognizerDirectionLeft;
	
	UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(rightSwipeRecognized:)];
	swipeRight.direction = UISwipeGestureRecognizerDirectionRight;
	
	// Attach all the gestures to my view
	[self.view addGestureRecognizer:singleTap];
	[self.view addGestureRecognizer:doubleTap];
	[self.view addGestureRecognizer:swipeLeft];
	[self.view addGestureRecognizer:swipeRight];
	
	
	
}

- (void)singleTapRecognized:(UITapGestureRecognizer *)tap{
	Flashcard *randomFlashcard = [self.model randomFlashcard];
	
	// animate transition
	[UIView animateWithDuration:1.0 animations:^{
		// Fade out old text of label
		self.flashcardLabel.alpha = 0;
	} completion:^(BOOL finished) {
		// Upon completion, call
		self.flashcardLabel.text = [randomFlashcard question];
		self.flashcardLabel.textColor = [UIColor blackColor];
		[UIView animateWithDuration:1.0 animations:^{
			self.flashcardLabel.alpha = 1;
		}];
	}];
}

- (void)doubleTapRecognized:(UITapGestureRecognizer *)tap{
	// get the right index of this flashcard
	int index = self.model.currentIndex;
	
	[UIView animateWithDuration:1.0 animations:^{
		// Fade out old text of label
		self.flashcardLabel.alpha = 0;
	} completion:^(BOOL finished) {
		// Upon completion, call
		self.flashcardLabel.text = [[self.model flashcardAtIndex:index] answer] ;
		self.flashcardLabel.textColor =[UIColor redColor];
		[UIView animateWithDuration:1.0 animations:^{
			self.flashcardLabel.alpha = 1;
		}];
	}];
}

- (void)leftSwipeRecognized:(UISwipeGestureRecognizer *)swipe{
	Flashcard *prevFlashcard = [self.model prevFlashcard];
	// animate transition
	[UIView animateWithDuration:1.0 animations:^{
		// Fade out old text of label
		self.flashcardLabel.alpha = 0;
	} completion:^(BOOL finished) {
		// Upon completion, call
		self.flashcardLabel.text = [prevFlashcard question];
		self.flashcardLabel.textColor = [UIColor blackColor];
		[UIView animateWithDuration:1.0 animations:^{
			self.flashcardLabel.alpha = 1;
		}];
	}];
	
	
}

- (void)rightSwipeRecognized:(UISwipeGestureRecognizer *)swipe{
	Flashcard *nextFlashcard = [self.model nextFlashcard];
	
	// animate transition
	[UIView animateWithDuration:1.0 animations:^{
		// Fade out old text of label
		self.flashcardLabel.alpha = 0;
	} completion:^(BOOL finished) {
		// Upon completion, call
		self.flashcardLabel.text = [nextFlashcard question];
		self.flashcardLabel.textColor = [UIColor blackColor];
		[UIView animateWithDuration:1.0 animations:^{
			self.flashcardLabel.alpha = 1;
		}];
	}];
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}


@end
